
from foldrpp import *
from datasets import student  # Import the student function from datasets.py
from timeit import default_timer as timer
from datetime import timedelta
import random
 
def main():
    model, data = student()  # Load the student dataset
    random.seed(42)
    data_train, data_test = split_data(data, ratio=0.4, rand=True)

    X_train, Y_train = split_xy(data_train)
    X_test, Y_test = split_xy(data_test)

    start = timer()
    model.fit(X_train, Y_train, ratio=0.5)
    end = timer()

    model.print_asp(simple=True)

    Y_test_hat = model.predict(X_test)
    acc, p, r, f1 = get_scores(Y_test_hat, Y_test)
    print('% acc', round(acc, 4), 'p', round(p, 4), 'r', round(r, 4), 'f1', round(f1, 4))
    print('% foldr++ costs: ', timedelta(seconds=end - start), '\n')

if __name__ == '__main__':
    main()
