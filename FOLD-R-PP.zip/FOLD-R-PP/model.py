import pickle
from foldrpp import Classifier

def load_model_from_file(file):
    with open(file, 'rb') as f:
        return pickle.load(f)

def main():
    model2 = load_model_from_file('example.model')
    model2.print_asp(simple=True)

if __name__ == '__main__':
    main()
