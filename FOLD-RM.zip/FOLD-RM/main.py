from foldrm import *
from datasets import *
from timeit import default_timer as timer
from datetime import timedelta
import numpy as np

def main():
    # Set the random seed
    np.random.seed(42)

    # Load the model and data
    model, data = student()

    # Split the data into training and testing sets
    data_train, data_test = split_data(data, ratio=0.2)

    # Train the model
    start = timer()
    model.fit(data_train, ratio=0.3)
    end = timer()

    # Print the learned rules
    model.print_asp(simple=True)

    # Evaluate the model on the test set
    Y = [d[-1] for d in data_test]
    Y_test_hat = model.predict(data_test)
    acc = get_scores(Y_test_hat, data_test)
    print('% acc', round(acc, 4), '# rules', len(model.crs))

    # Print additional evaluation metrics
    acc, p, r, f1 = scores(Y_test_hat, Y, weighted=True)
    print('% acc', round(acc, 4), 'macro p r f1', round(p, 4), round(r, 4), round(f1, 4), '# rules', len(model.crs))
    print('% foldrm costs: ', timedelta(seconds=end - start), '\n')

if __name__ == '__main__':
    main()
