import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import time

# Function to convert Prolog-like data to a Pandas DataFrame
def prolog_data_to_dataframe(data):
    # Define a mapping from Prolog-like predicates to column names
    column_mapping = {
        'large_family': 'large_family',
        'renta_minima_insercion': 'renta_minima_insercion',
        'sibling_enroll_center': 'sibling_enroll_center',
        'same_education_district': 'same_education_district',
        'come_non_bilingual': 'come_non_bilingual',
        'want_bilingual_section': 'want_bilingual_section',
        'b1_certificate': 'b1_certificate',
    }

    # Create a dictionary with column names and corresponding values
    student_data_dict = {column_mapping[key]: [value] for key, value in data.items()}

    # Convert the dictionary to a Pandas DataFrame
    student_df = pd.DataFrame(student_data_dict)

    return student_df

# Function to predict whether a student obtains a place or not
def predict_obtain_place(data, classifier):
    # Convert Prolog-like data to Pandas DataFrame
    student_df = prolog_data_to_dataframe(data)

    # Use the trained classifier to make predictions
    prediction = classifier.predict(student_df)

    return prediction[0]

# Load the dataset
data = pd.read_csv("student.csv")

# Split the data into features (X) and the target variable (y)
X = data.drop(columns=["Student", "OBTAIN_PLACE"])
y = data["OBTAIN_PLACE"]

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create and train a Random Forest classifier
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)

# Make predictions on the test data
y_pred = clf.predict(X_test)

# Evaluate the model's performance
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, pos_label='Yes')
recall = recall_score(y_test, y_pred, pos_label='Yes')
f1 = f1_score(y_test, y_pred, pos_label='Yes')

print(f"Accuracy: {accuracy:.2f}")
print(f"Precision: {precision:.2f}")
print(f"Recall: {recall:.2f}")
print(f"F1 Score: {f1:.2f}")

# Given student's data
student_data = {
    'large_family': 1,
    'renta_minima_insercion': 1,
    'sibling_enroll_center': 0,
    'same_education_district': 1,
    'come_non_bilingual': 1,
    'want_bilingual_section': 1,
    'b1_certificate': 1,
}

# Test the function with the given student's data
result = predict_obtain_place(student_data, clf)

# Output the result
print(f"Prediction for student01: {result}")
